import React from "react";
import { Link } from "react-router-dom";
import "./navbar.css";

const LinkComponent = ({ name, to }) => {
  return (
    <li className="link">
      <Link to={to}>{name}</Link>
    </li>
  );
};

const Navbar = () => {
  return (
    <div className="shadow-sm bg-white mb-2">
      <div className="container">
        <nav className="navbar">
          <div className="navbar_left">
            <h5>Ecommarce Clone</h5>
          </div>

          <div className="navbar_right">
            <ul className="navbar_right_ul">
              <LinkComponent to="/" name={"Home"} />
              {/* <LinkComponent to="/about" name="About" />
              <LinkComponent to="/jobs" name="Jobs" />
              <LinkComponent to="/" name="My network" /> */}
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;
