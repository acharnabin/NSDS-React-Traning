export const photoUrl="https://rekojako-admin.dedicateddevelopers.us/uploads/meeting"
export const baseUrl="https://rekojako-admin.dedicateddevelopers.us/api"