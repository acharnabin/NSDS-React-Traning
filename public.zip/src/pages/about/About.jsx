import axios from "axios";
import React, { useEffect, useState } from "react";
import AboutCard from "../../component/AboutCardComponent/AboutCard";

const About = () => {
  const [data, setdata] = useState([]);
  const [loading, setloading] = useState(false);

  const getData = async () => {
    setloading(true);

    // let payload = {
    //   name: "this is name",
    //   address: "this is adress",
    // };

    let payload = new FormData();

    payload.append("title", "this is name");
    payload.append("body", "this is adress");

    let res = await axios.get(
      "https://jsonplaceholder.typicode.com/posts",
      payload
    );
    setloading(false);
    setdata(res.data);
  };

  // useEffect(() => {
  //   getData();
  // }, []);

  return (
    <div className="container p-2">
      <button onClick={getData}>submit</button>
      {loading && <h1>Loading........</h1>}
      {data?.map((item, index) => {
        return <AboutCard item2={item} />;
      })}
    </div>
  );
};

export default About;
