import React from "react";

const PageNotFound = () => {
  return (
    <div>
      <img
        style={{
          height: "200px",
          width: "200px",
        }}
        src="https://previews.123rf.com/images/kaymosk/kaymosk1804/kaymosk180400006/100130939-error-404-page-not-found-error-with-glitch-effect-on-screen-vector-illustration-for-your-design-.jpg"
      />
    </div>
  );
};

export default PageNotFound;
