import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Home = () => {
  const [loading, setloading] = useState(false);
  const [data, setdata] = useState(null);
  const [data_copy, setdata_copy] = useState(null);
  const [search, setsearch] = useState("");
  const [filter_price, setFilter_price] = useState(0);

  const GetProductData = async () => {
    setloading(true);
    let res = await axios.get("https://fakestoreapi.com/products");
    setloading(false);
    setdata_copy(res.data);
    setdata(res.data);
  };

  const handleSerch = (e) => {
    e.preventDefault();

    let filter_data = data_copy.filter(
      (item) => item?.title?.toLowerCase() === search.toLowerCase()
    );

    setdata(filter_data);
  };

  const handleFilter = () => {};

  useEffect(() => {
    GetProductData();
  }, []);

  useEffect(() => {
    if (search?.length === 0 && data_copy !== null) {
      setdata(data_copy);
    }
  }, [search?.length]);

  useEffect(() => {
    if (filter_price !== 0) {
      let filter_data_by_price = data_copy.filter(
        (item) => parseInt(item?.price) <= filter_price
      );
      setdata(filter_data_by_price);
    }
  }, [filter_price]);

  return (
    <div className="container">
      <div className="card p-2 mb-3">
        <form onSubmit={handleSerch}>
          <div class="form-group">
            <label for="exampleInputEmail1">Search something</label>
            <input
              value={search}
              onChange={(e) => setsearch(e.target.value)}
              type="text"
              class="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              placeholder="Enter email"
            />
          </div>

          <button type="submit" class="btn m-3 btn-primary">
            Search
          </button>
        </form>
      </div>

      <div className="card p-2 mb-3">
        <h1>Price filter</h1>
        <div>
          <button
            onClick={() => setFilter_price(100)}
            className={
              filter_price === 100
                ? "btn btn-danger mx-2"
                : "btn btn-primary mx-2"
            }
          >
            under 100
          </button>
          <button
            onClick={() => setFilter_price(200)}
            className={
              filter_price === 200
                ? "btn btn-danger mx-2"
                : "btn btn-primary mx-2"
            }
          >
            under 200
          </button>
          <button
            onClick={() => setFilter_price(500)}
            className={
              filter_price === 500
                ? "btn btn-danger mx-2"
                : "btn btn-primary mx-2"
            }
          >
            under 500
          </button>
        </div>
      </div>

      {loading ? (
        <h1>Loading.....</h1>
      ) : (
        <>
          {data?.length === 0 && <h1>No product found</h1>}

          {data?.length > 0 && (
            <>
              <div className="row">
                <h3 className="text-danger">Products- {data?.length}</h3>
                {data?.map((item) => {
                  return (
                    <div className="col-4">
                      <div className="card">
                        <img
                          className="card-img-top"
                          src={item?.image}
                          alt={item?.title}
                        />
                        <div className="card-body">
                          <h5 className="card-title">{item?.title}</h5>
                          <p className="card-text">{item?.description}</p>
                          <Link
                            to={`/product-details/${item.id}`}
                            className="btn btn-primary"
                          >
                            $ {item?.price}
                          </Link>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default Home;
