import { useEffect, useState } from "react";
import { Route, Routes } from "react-router";
import "./app.css";
import AboutCard from "./component/AboutCardComponent/AboutCard";
import Navbar from "./component/Navbar/Navbar";
import About from "./pages/about/About";
import Home from "./pages/home/Home";
import Jobs from "./pages/jobs/Jobs";
import PageNotFound from "./pages/pageNotFound/PageNotFound";
import ProductDetails from "./pages/Productdetails/ProductDetails";

// import TestComponent from "./component/TestComponent";

function App() {
  const [state, setState] = useState("Hello");

  const [multiple, setMultiple] = useState({
    name: "This is name",
    object: {
      id: 1,
      name: "test",
    },
    _address: ["kolkata", "simla"],
  });

 

  const [inputState, setInputState] = useState("");
  const [object_id, setObject_id] = useState("");
  const [object_name, setObject_name] = useState("");

  const [counter, setcounter] = useState(0);
  const [counter2, setcounter2] = useState(0);

  const [color, setColor] = useState("text-primary");

  const handleSetState = (e) => {
    e.preventDefault();
    // setState(inputState);

    let temp = multiple._address;

    temp.push(object_id);
    temp.push(object_name);

    setMultiple({
      ...multiple,
      name: inputState,
      object: {
        id: object_id,
        name: object_name,
        name2: "this is name 2",
      },
      _address: temp,
    });
  };

  const incr = () => {
    setcounter(counter + 1);
  };

  const decr = () => {
    setcounter(counter - 1);
  };

  const incr2 = () => {
    setcounter2(counter2 + 1);
  };

  const decr2 = () => {
    setcounter2(counter2 - 1);
  };

  useEffect(() => {
    if (counter % 2 === 0 && counter2 % 2 === 0) {
      setColor("text-success");
    } else {
      setColor("text-danger");
    }
  }, [counter, counter2]);

  return (
    <>
      {/* <div className="card mt-1 p-2">
        <button className="btn btn-primary" onClick={incr}>
          +
        </button>
        <h1 className={color}>counter=>{counter}</h1>
        <button className="btn btn-primary" onClick={decr}>
          -
        </button>
      </div>

      <div className="card mt-1 p-2">
        <button className="btn btn-primary" onClick={incr2}>
          +
        </button>
        <h1 className={color}>counter 2=>{counter2}</h1>
        <button className="btn btn-primary" onClick={decr2}>
          -
        </button>
      </div> */}

      {/* <form onSubmit={handleSetState}>
        <input
          value={inputState}
          onChange={(e) => setInputState(e.target.value)}
        />

        <input
          placeholder="for object"
          value={object_id}
          onChange={(e) => setObject_id(e.target.value)}
        />
        <input
          placeholder="for object name"
          value={object_name}
          onChange={(e) => setObject_name(e.target.value)}
        />
        <button type="submit" className="btn btn-primary">
          Chnage value
        </button>
      </form>

      <h1>{multiple.name}</h1>

      <h1>Object</h1>
      <h1>
        {multiple.object.id},{multiple.object.name},{multiple?.object?.name2}
      </h1>

      {multiple?._address?.map((item) => {
        return <p>{item}</p>;
      })} */}
      {/* <Navbar/>
  
    <Routes>



    <Route   path="/" element={<Home/>}   />
    <Route   path="/about" element={<About/>}   />
    <Route   path="/jobs" element={<Jobs/>}   />


    <Route   path="*" element={<PageNotFound/>}   />



    </Routes> */}
      <Navbar />
    
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/product-details/:id" element={<ProductDetails />} />
        <Route path="/about2" element={<About />} />

        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </>
  );
}

export default App;
